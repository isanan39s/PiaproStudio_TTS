# LibreSVIP

[![PyPi](https://img.shields.io/pypi/v/libresvip)](https://pypi.org/project/libresvip/)
[![Python Version](https://img.shields.io/pypi/pyversions/libresvip.svg)](https://pypi.org/project/libresvip/)
[![PyPI - Downloads](https://static.pepy.tech/badge/libresvip/month)](https://pypi.org/project/libresvip/)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Checked with pyrefly](https://img.shields.io/endpoint?url=https://pyrefly.org/badge.json)](https://github.com/facebook/pyrefly/)
[![License](https://img.shields.io/pypi/l/libresvip?color=blue)](https://opensource.org/licenses/MIT)
[![GitHub Build](https://img.shields.io/github/actions/workflow/status/SoulMelody/LibreSVIP/package.yml?label=packaging)](https://github.com/SoulMelody/LibreSVIP/actions/workflows/package.yml?query=workflow%3APackaging)
[![lite-badge](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://soulmelody.github.io/libresvip-pwa/)

LibreSVIP is a cross-platform and universal converter for many Singing Voice Synthesis (aka SVS) project formats.

## Installation

Download from github releases: [Releases](https://github.com/SoulMelody/LibreSVIP/releases)

Alternatively, you can install LibreSVIP with desktop support via pip (requires python 3.10+):

```bash
pip install libresvip[desktop]
```

## Translations

![zh-CN translation](https://img.shields.io/badge/dynamic/json?color=blue&label=zh-CN&style=flat&logo=crowdin&query=%24.progress%5B2%5D.data.translationProgress&url=https%3A%2F%2Fbadges.awesome-crowdin.com%2Fstats-16219268-645830.json)
![ja translation](https://img.shields.io/badge/dynamic/json?color=blue&label=ja&style=flat&logo=crowdin&query=%24.progress%5B1%5D.data.translationProgress&url=https%3A%2F%2Fbadges.awesome-crowdin.com%2Fstats-16219268-645830.json)
![de translation](https://img.shields.io/badge/dynamic/json?color=blue&label=de&style=flat&logo=crowdin&query=%24.progress%5B0%5D.data.translationProgress&url=https%3A%2F%2Fbadges.awesome-crowdin.com%2Fstats-16219268-645830.json)

If you also want to add or contribute to a translation, check [LibreSVIP's page on Crowdin](https://crowdin.com/project/libresvip).

## References

This project is highly inspired by following projects:

- [OpenSVIP](https://github.com/yqzhishen/opensvip)
- [Utaformatix3](https://github.com/sdercolin/utaformatix3)

Other projects that are related to this project:

- [QNrbf](https://github.com/SineStriker/QNrbf)

The following article will give you a brief introduction about python libraries for text and binary parsing:

- [Parsing In Python: Tools And Libraries](https://tomassetti.me/parsing-in-python/)

## License

LibreSVIP is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
